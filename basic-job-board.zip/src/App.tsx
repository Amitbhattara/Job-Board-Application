import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, useParams } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import JobList from './components/JobList';
import AppliedJobs from './components/AppliedJobs';
import SavedJobs from './components/SavedJobs';
import './App.css';
import jobData from './jobs.json';
import JobDetails from './components/JobDetails';

export interface Job {
  id: number;
  title: string;
  location: string;
  jobDescription: string;
  rolesResponsibilities: string[];
}

const App: React.FC = () => {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [appliedJobs, setAppliedJobs] = useState<Job[]>([]);
  const [savedJobs, setSavedJobs] = useState<Job[]>([]);

  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        setJobs(jobData);
      } catch (error: any) {
        setError(error.message);
      } finally {
        setIsLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleApplyJob = (job: Job) => {
    setAppliedJobs([...appliedJobs, job]);
    setSavedJobs(savedJobs.filter((savedJob) => savedJob.id !== job.id));
  };

  const handleSaveJob = (job: Job) => {
    setSavedJobs([...savedJobs, job]);
  };

  return (
    <Router>
      <div className="app">
        <Header />
        <main className="app-content">
          {error && <div>Error occured while fetching jobs</div>}
          {isLoading ? (
            <div className='no-job'>Loading jobs...</div>
          ): (
            <Routes>
            <Route path="/" element={<JobList
              jobs={jobs}
              onApplyJob={handleApplyJob}
              onSaveJob={handleSaveJob}
              savedJobs={savedJobs}
              appliedJobs={appliedJobs}
            />} />
            <Route path="/applied-jobs" element={<AppliedJobs appliedJobs={appliedJobs} />} />
            <Route path="/saved-jobs" element={<SavedJobs
              savedJobs={savedJobs}
              onApplyJob={handleApplyJob}
              appliedJobs={appliedJobs}
            />} />
            <Route path="/job/:id" element={<JobDetailsWrapper jobs={jobs} onApplyJob={handleApplyJob} appliedJobs={appliedJobs} />} />
          </Routes>
          )}
          
        </main>
        <Footer />
      </div>
    </Router>
  );
};

interface JobDetailsWrapperProps {
  jobs: Job[];
  onApplyJob: (job: Job) => void;
  appliedJobs: Job[];
}

const JobDetailsWrapper = ({ jobs, onApplyJob, appliedJobs }: JobDetailsWrapperProps) => {
  const { id } = useParams();

  const job = jobs.find((job) => job.id === Number(id));

  if (!job) {
    return <div>Job not found</div>;
  }

  return <JobDetails job={job} onApplyJob={onApplyJob}
  appliedJobs={appliedJobs} />
};

export default App;
