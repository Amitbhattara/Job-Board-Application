import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@mui/material';
import { Job } from '../App';

interface SavedJobsProps {
  savedJobs: Job[];
  appliedJobs: Job[];
  onApplyJob: (job: Job) => void;
}

const SavedJobs: React.FC<SavedJobsProps> = ({ savedJobs, appliedJobs, onApplyJob }) => {

  return (
    <div>
      <h2>Saved Jobs</h2>
      {savedJobs.length === 0 ? (
        <p>No saved jobs yet. <Link to="/">Browse jobs</Link></p>
      ) : (
        <ul>
          {savedJobs.map((job) => (
            <li key={job.id}>
              {job.title} - {job.location}
              <Button
                variant="contained"
                color="primary"
                className='saved-btn'
                onClick={() => onApplyJob(job)}
                disabled={appliedJobs.some((savedJob) => savedJob.id === job.id)}
              >
                Apply
              </Button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default SavedJobs;
