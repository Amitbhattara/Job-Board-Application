
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Header from './Header';

describe('Header component', () => {
    it('renders header', () => {
      render(<MemoryRouter><Header /></MemoryRouter>
      );
      expect(screen.getByText(/Job Board App/i)).toBeInTheDocument();
  });
});