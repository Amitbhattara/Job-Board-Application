
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import ConfirmationModal from './ConfirmationModal';

describe('ConfirmationModal component', () => {
    it('renders modal', () => {
      render(<MemoryRouter><ConfirmationModal  open={true} onClose={jest.fn()}/></MemoryRouter>
      );
      expect(screen.getByText(/You have successfully applied for this job/i)).toBeInTheDocument();
  });
});