import React from 'react';
import { Grid } from '@mui/material';
import JobCard from './JobCard';
import { Job } from '../App';

interface JobListProps {
  jobs: Job[];
  onApplyJob: (job: Job) => void;
  onSaveJob: (job: Job) => void;
  savedJobs: Job[];
  appliedJobs: Job[];
}

const JobList: React.FC<JobListProps> = ({ jobs, onApplyJob, onSaveJob, savedJobs, appliedJobs }) => {

  return (
    <Grid container spacing={2}>
      {jobs.map((job) => (
        <Grid item key={job.id} xs={12} sm={6} md={4}>
          <JobCard job={job} onApplyJob={onApplyJob} savedJobs={savedJobs} appliedJobs={appliedJobs} onSaveJob={onSaveJob}/>
        </Grid>
      ))}
      {jobs.length === 0 && (
        <div className='no-job'>No Jobs Found!</div>
      )}
    </Grid>
  );
};

export default JobList;
