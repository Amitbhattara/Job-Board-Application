
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import JobList from './JobList';

describe('JobList component', () => {
  const props ={
    jobs: [{
      "id": 1,
      "title": "Full Stack Developer",
      "location": "New York, NY",
      "jobDescription": "We are looking for a skilled Full Stack Developer to join our team...",
      "rolesResponsibilities": [
        "Develop and maintain front-end and back-end systems",
        "Collaborate with the design team to implement UI/UX designs",
        "Test and debug code",
        "Deploy applications to production environment"
      ]
    }],
    onApplyJob: jest.fn(),
    onSaveJob: jest.fn(),
    savedJobs: [],
    appliedJobs: []
  }
    it('renders job card', () => {
      render(<MemoryRouter><JobList {...props}/></MemoryRouter>
      );
      expect(screen.getByText("Full Stack Developer")).toBeInTheDocument();
  });
});