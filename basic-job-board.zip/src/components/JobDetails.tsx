import React from 'react';
import { Typography, Button, Paper } from '@mui/material';
import { Link } from 'react-router-dom';
import { Job } from '../App';

interface JobDetailsProps {
  job: Job;
  onApplyJob: (job: Job) => void;
  appliedJobs: Job[];
}

const JobDetails: React.FC<JobDetailsProps> = ({ job, onApplyJob, appliedJobs }) => {
  const isJobApplied = appliedJobs.some((appliedJob) => appliedJob.id === job.id);

  const styles = {
    root: {
      padding: '16px',
    },
    header: {
      marginBottom: '16px',
    },
    description: {
      marginBottom: '16px',
    },
    responsibilities: {
      marginBottom: '16px',
    },
  };

  return (
    <Paper style={styles.root}>
      <Typography variant="h4" style={styles.header}>
        {job.title}
      </Typography>
      <Typography variant="h6" gutterBottom>
        Location: {job.location}
      </Typography>
      <Typography variant="body1" style={styles.description}>
        {job.jobDescription}
      </Typography>
      <Typography variant="h6" gutterBottom style={styles.responsibilities}>
        Roles and Responsibilities:
      </Typography>
      <ul>
        {job.rolesResponsibilities.map((role, index) => (
          <li key={index}>{role}</li>
        ))}
      </ul>
      {isJobApplied ? (
        <Button variant="contained" color="primary" className='mr-10' disabled>
          Applied
        </Button>
      ) : (
        <Button variant="contained" color="primary" className='mr-10' onClick={()=>onApplyJob(job)}>
          Apply
        </Button>
      )}
      <Button variant="contained" color="primary" component={Link} to="/">
        Go Back
      </Button>
    </Paper>
  );
};

export default JobDetails;
