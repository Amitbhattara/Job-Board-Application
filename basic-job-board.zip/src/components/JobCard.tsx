import React, { useState } from 'react';
import { Card, CardContent, Typography, Button } from '@mui/material';
import { Link } from 'react-router-dom';
import { Job } from '../App';
import ConfirmationModal from './ConfirmationModal';
import CustomSnackbar from './CustomSnackbar';

interface JobCardProps {
    job: Job;
    onApplyJob: (job: Job) => void;
    onSaveJob: (job: Job) => void;
    savedJobs: Job[];
    appliedJobs: Job[];
}

const JobCard: React.FC<JobCardProps> = ({ job, onApplyJob, onSaveJob, savedJobs, appliedJobs }) => {

    const [openSnackbar, setOpenSnackbar] = React.useState(false);

    const handleSaveJob = () => {
        setOpenSnackbar(true);
        onSaveJob(job);
    }

  const handleClose = () => {
    setOpenSnackbar(false);
  };

    const [isModalOpen, setModalOpen] = useState(false);

    const handleApply = () => {
        onApplyJob(job);
        setModalOpen(true);
    };

    const handleCloseModal = () => {
        setModalOpen(false);
    };


    const isJobApplied = appliedJobs.some((appliedJob) => appliedJob.id === job.id);

    return (
        <Card className='job-card'>
            <CardContent>
                <Typography variant="h6" component={Link} to={`/job/${job.id}`}>{job.title}</Typography>
                <Typography variant="body2">{job.jobDescription}</Typography>
                <Typography variant="caption">{job.location}</Typography>
                <div className='mt-10'>
                    {isJobApplied ? (
                        <Button variant="contained" color="primary" disabled>
                            Applied
                        </Button>
                    ) : (
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={handleApply}
                            className='mr-10'
                            disabled={appliedJobs.some((savedJob) => savedJob.id === job.id)}
                        >
                            Apply
                        </Button>
                    )}
                    {!isJobApplied && <Button
                        variant="outlined"
                        color="primary"
                        onClick={handleSaveJob}
                        disabled={savedJobs.some((savedJob) => savedJob.id === job.id)}
                    >
                        Save
                    </Button>}
                </div>
            </CardContent>
            <ConfirmationModal open={isModalOpen} onClose={handleCloseModal} />
            <CustomSnackbar open={openSnackbar} handleClose={handleClose} />
        </Card>
    );
};

export default JobCard;
