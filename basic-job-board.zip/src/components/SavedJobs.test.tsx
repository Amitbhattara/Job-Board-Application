
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import SavedJobs from './SavedJobs';

describe('SavedJobs component', () => {
    it('renders no saved jobs', () => {
        render(<MemoryRouter><SavedJobs savedJobs={[]} appliedJobs={[]} onApplyJob={jest.fn()} /></MemoryRouter>
        );
        expect(screen.getByText('No saved jobs yet.')).toBeInTheDocument();
    });

    it('renders saved jobs', () => {
      render(<MemoryRouter><SavedJobs savedJobs={[{
        "id": 1,
        "title": "Full Stack Developer",
        "location": "New York, NY",
        "jobDescription": "We are looking for a skilled Full Stack Developer to join our team...",
        "rolesResponsibilities": [
          "Develop and maintain front-end and back-end systems",
          "Collaborate with the design team to implement UI/UX designs",
          "Test and debug code",
          "Deploy applications to production environment"
        ]
      }]} appliedJobs={[]} onApplyJob={jest.fn()} /></MemoryRouter>
      );
      expect(screen.getByText(/Full Stack Developer/i)).toBeInTheDocument();
  });
});