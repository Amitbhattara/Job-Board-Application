import React from 'react';
import { Modal, Box, Typography, Button } from '@mui/material';

interface ConfirmationModalProps {
    open: boolean;
    onClose: () => void;
}

const ConfirmationModal = ({ open, onClose }: ConfirmationModalProps) => {
  return (
    <Modal
      open={open}
      onClose={onClose}
      aria-labelledby="confirmation-modal-title"
      aria-describedby="confirmation-modal-description"
    >
      <Box sx={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', width: 400, bgcolor: 'background.paper', boxShadow: 24, p: 4 }}>
        <Typography id="confirmation-modal-title" variant="h6" component="h2" gutterBottom>
          Application Confirmation
        </Typography>
        <Typography id="confirmation-modal-description" variant="body1" gutterBottom>
          You have successfully applied for this job
        </Typography>
        <Box sx={{ display: 'flex', justifyContent: 'space-between', mt: 2 }}>
          <Button variant="contained" onClick={onClose}>
            OK
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default ConfirmationModal;
