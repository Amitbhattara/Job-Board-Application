
import { render, screen } from '@testing-library/react';
import AppliedJobs from './AppliedJobs';
import { MemoryRouter } from 'react-router-dom';

describe('AppliedJobs component', () => {
    it('renders no applied jobs', () => {
        render(<MemoryRouter><AppliedJobs appliedJobs={[]}/></MemoryRouter>
        );
        expect(screen.getByText('No applied jobs yet.')).toBeInTheDocument();
    });

    it('renders applied jobs', () => {
      render(<MemoryRouter><AppliedJobs appliedJobs={[{
        "id": 1,
        "title": "Full Stack Developer",
        "location": "New York, NY",
        "jobDescription": "We are looking for a skilled Full Stack Developer to join our team...",
        "rolesResponsibilities": [
          "Develop and maintain front-end and back-end systems",
          "Collaborate with the design team to implement UI/UX designs",
          "Test and debug code",
          "Deploy applications to production environment"
        ]
      }]}/></MemoryRouter>
      );
      expect(screen.getByText(/Full Stack Developer/i)).toBeInTheDocument();
  });
});