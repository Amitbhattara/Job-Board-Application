const Footer = () => {
  return (
      <div className='app-footer'>
          © 2024 Job Board App
      </div>
  );
};

export default Footer;
