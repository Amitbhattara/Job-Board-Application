
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Footer from './Footer';

describe('Footer component', () => {
    it('renders footer', () => {
      render(<MemoryRouter><Footer /></MemoryRouter>
      );
      expect(screen.getByText(/© 2024 Job Board App/i)).toBeInTheDocument();
  });
});