import React from 'react';
import { Link } from 'react-router-dom';
import { Job } from '../App';

interface AppliedJobsProps {
  appliedJobs: Job[];
}

const AppliedJobs: React.FC<AppliedJobsProps> = ({ appliedJobs }) => {
  return (
    <div>
      <h2>Applied Jobs</h2>
      {appliedJobs.length === 0 ? (
        <p>No applied jobs yet. <Link to="/">Let's begin!</Link></p>
      ) : (
        <ul>
          {appliedJobs.map((job) => (
            <li key={job.id}>{job.title} - {job.location}</li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AppliedJobs;
