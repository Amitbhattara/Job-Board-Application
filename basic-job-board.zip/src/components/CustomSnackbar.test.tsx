
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import CustomSnackbar from './CustomSnackbar';

describe('CustomSnackbar component', () => {
    it('renders snackbar', () => {
      render(<MemoryRouter><CustomSnackbar open={true} handleClose={jest.fn()}/></MemoryRouter>
      );
      expect(screen.getByText(/Job saved/i)).toBeInTheDocument();
  });
});