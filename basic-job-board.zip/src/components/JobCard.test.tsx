
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import JobCard from './JobCard';

describe('JobCard component', () => {
  const props ={
    job: {
      "id": 1,
      "title": "Full Stack Developer",
      "location": "New York, NY",
      "jobDescription": "We are looking for a skilled Full Stack Developer to join our team...",
      "rolesResponsibilities": [
        "Develop and maintain front-end and back-end systems",
        "Collaborate with the design team to implement UI/UX designs",
        "Test and debug code",
        "Deploy applications to production environment"
      ]
    },
    onApplyJob: jest.fn(),
    onSaveJob: jest.fn(),
    savedJobs: [],
    appliedJobs: []
  }
    it('renders job card', () => {
      render(<MemoryRouter><JobCard {...props}/></MemoryRouter>
      );
      expect(screen.getByText(/We are looking for a skilled Full Stack Developer to join our team.../i)).toBeInTheDocument();
      expect(screen.getByText(/Apply/i)).toBeInTheDocument();
      expect(screen.getByText(/Save/i)).toBeInTheDocument();
  });
});